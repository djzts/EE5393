LI DAOQI
5101728
daoqi001@umn.edu

Q2 is a function that verify Q2 (d) which functions from f0 to f15 is implemented in this structure. 
A is the connection description matrix, for exampe A(i,j)=xbar means there is a xbar switch connected between node i and node j. It will automatically connect the same switch from node j to i.
The final print out of imFunc means f0 to f14 are implement such many times. 
fucntionNum will tell you between node number in 2nd line and 3rd line the number in 1st line fucntion is implemented between there two swtich.

Q4aprintout is Q4(a) related print out. Evaluate these code to print related graph. 

Q4bprintout is Q4(b) related print out. Evaluate these code to print related graph. 

Q4aSim and Q4bsim are simulation script, manually change parameters trialNum and n, p, m to simulate different condition. 
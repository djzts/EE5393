function [f] = targetFunction (t)
f=1/3*(1-t+t.^2-t.^3+t.^4-t.^5);
end

